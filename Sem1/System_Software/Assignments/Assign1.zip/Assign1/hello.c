#include<stdio.h>
int main(int argc,char *argv[]){
	printf("Hello %s\n",argv[1]);
}