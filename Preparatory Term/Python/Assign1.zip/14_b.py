a = input()
if(a<5):
    print "infant"
elif(a>=5 and a<18):
    print "child"
elif(a>=18):
    print "adult"
