guess = raw_input()[0].lower()
if(guess=='y'):
    print('You said \'yes\'')
print('Hello World!')
