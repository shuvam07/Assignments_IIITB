a = input()
if(a>=0 and a<18):
    print "child"
elif(a>=18):
    print "adult"
