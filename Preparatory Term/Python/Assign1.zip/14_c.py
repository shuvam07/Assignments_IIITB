a = input()
count = 0
for i in range(a):
    print "Hello World!"
