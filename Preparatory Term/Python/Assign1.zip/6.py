import sys
first = raw_input()
last = raw_input()
print (first[0:-1] + ' ' + last)
