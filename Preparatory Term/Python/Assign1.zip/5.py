import sys
side1 = input()
side2 = input()
print (side1*side1 + side2*side2)
