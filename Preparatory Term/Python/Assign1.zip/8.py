abhiraj = 990
leon = 140 + 150
vigyan = 1100
avg  = (abhiraj+leon+vigyan)/3
print "Abhiraj pays {}".format(avg-abhiraj)
print "Leon pays {}".format(avg-leon)
print "vigyan pays {}".format(avg-vigyan)
