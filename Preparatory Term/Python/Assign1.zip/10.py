age = input()
if(age < 18):
    print('Noddy, Nancy Drew, Panchatantra, Amar ChitraKatha, Tintin, Asterix')
elif(age>=18):
    print('Anna Karenin, Godaan , Geetanjali, Fountainhead, Midnight\'s Children')
