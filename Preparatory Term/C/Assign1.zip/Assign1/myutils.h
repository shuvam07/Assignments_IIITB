
int* load_generator(void);

void print_arr(int*,int);
