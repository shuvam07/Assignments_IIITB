
void quick_sort(int *,int);

void insertion_sort(int *,int);